<?php

declare(strict_types=1);

namespace DoctrineMigrations;

use Doctrine\DBAL\Schema\Schema;
use Doctrine\Migrations\AbstractMigration;

/**
 * Auto-generated Migration: Please modify to your needs!
 */
final class Version20210427233056 extends AbstractMigration
{
    public function getDescription() : string
    {
        return '';
    }

    public function up(Schema $schema) : void
    {
        // this up() migration is auto-generated, please modify it to your needs
        $this->addSql('CREATE TABLE article (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, refutilisateur_id INTEGER NOT NULL, titre VARCHAR(255) DEFAULT NULL, creation_date DATE DEFAULT NULL, modification_date DATE DEFAULT NULL, contenu VARCHAR(255) NOT NULL)');
        $this->addSql('CREATE INDEX IDX_23A0E667088F601 ON article (refutilisateur_id)');
        $this->addSql('CREATE TABLE article_categorie (article_id INTEGER NOT NULL, categorie_id INTEGER NOT NULL, PRIMARY KEY(article_id, categorie_id))');
        $this->addSql('CREATE INDEX IDX_934886107294869C ON article_categorie (article_id)');
        $this->addSql('CREATE INDEX IDX_93488610BCF5E72D ON article_categorie (categorie_id)');
        $this->addSql('CREATE TABLE article_keywords (article_id INTEGER NOT NULL, keywords_id INTEGER NOT NULL, PRIMARY KEY(article_id, keywords_id))');
        $this->addSql('CREATE INDEX IDX_FFB741357294869C ON article_keywords (article_id)');
        $this->addSql('CREATE INDEX IDX_FFB741356205D0B8 ON article_keywords (keywords_id)');
        $this->addSql('CREATE TABLE categorie (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, categorie VARCHAR(100) DEFAULT NULL)');
        $this->addSql('CREATE TABLE commentaire (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, article_id INTEGER DEFAULT NULL, contenu CLOB DEFAULT NULL, creation_date DATE DEFAULT NULL)');
        $this->addSql('CREATE INDEX IDX_67F068BC7294869C ON commentaire (article_id)');
        $this->addSql('CREATE TABLE keywords (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, keyword VARCHAR(200) DEFAULT NULL)');
        $this->addSql('CREATE TABLE utilisateur (id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, email VARCHAR(180) NOT NULL, roles CLOB NOT NULL --(DC2Type:json)
        , password VARCHAR(255) NOT NULL, role VARCHAR(50) DEFAULT NULL)');
        $this->addSql('CREATE UNIQUE INDEX UNIQ_1D1C63B3E7927C74 ON utilisateur (email)');
    }

    public function down(Schema $schema) : void
    {
        // this down() migration is auto-generated, please modify it to your needs
        $this->addSql('DROP TABLE article');
        $this->addSql('DROP TABLE article_categorie');
        $this->addSql('DROP TABLE article_keywords');
        $this->addSql('DROP TABLE categorie');
        $this->addSql('DROP TABLE commentaire');
        $this->addSql('DROP TABLE keywords');
        $this->addSql('DROP TABLE utilisateur');
    }
}
