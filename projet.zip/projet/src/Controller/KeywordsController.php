<?php

namespace App\Controller;

use App\Entity\Keywords;
use App\Form\KeywordsType;
use App\Repository\KeywordsRepository;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Annotation\Route;

/**
 * @Route("/keywords")
 */
class KeywordsController extends AbstractController
{
    /**
     * @Route("/", name="keywords_index", methods={"GET"})
     */
    public function index(KeywordsRepository $keywordsRepository): Response
    {
        return $this->render('keywords/index.html.twig', [
            'keywords' => $keywordsRepository->findAll(),
        ]);
    }

    /**
     * @Route("/new", name="keywords_new", methods={"GET","POST"})
     */
    public function new(Request $request): Response
    {
        $keyword = new Keywords();
        $form = $this->createForm(KeywordsType::class, $keyword);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->persist($keyword);
            $entityManager->flush();

            return $this->redirectToRoute('keywords_index');
        }

        return $this->render('keywords/new.html.twig', [
            'keyword' => $keyword,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="keywords_show", methods={"GET"})
     */
    public function show(Keywords $keyword): Response
    {
        return $this->render('keywords/show.html.twig', [
            'keyword' => $keyword,
        ]);
    }

    /**
     * @Route("/{id}/edit", name="keywords_edit", methods={"GET","POST"})
     */
    public function edit(Request $request, Keywords $keyword): Response
    {
        $form = $this->createForm(KeywordsType::class, $keyword);
        $form->handleRequest($request);

        if ($form->isSubmitted() && $form->isValid()) {
            $this->getDoctrine()->getManager()->flush();

            return $this->redirectToRoute('keywords_index');
        }

        return $this->render('keywords/edit.html.twig', [
            'keyword' => $keyword,
            'form' => $form->createView(),
        ]);
    }

    /**
     * @Route("/{id}", name="keywords_delete", methods={"POST"})
     */
    public function delete(Request $request, Keywords $keyword): Response
    {
        if ($this->isCsrfTokenValid('delete'.$keyword->getId(), $request->request->get('_token'))) {
            $entityManager = $this->getDoctrine()->getManager();
            $entityManager->remove($keyword);
            $entityManager->flush();
        }

        return $this->redirectToRoute('keywords_index');
    }
}
